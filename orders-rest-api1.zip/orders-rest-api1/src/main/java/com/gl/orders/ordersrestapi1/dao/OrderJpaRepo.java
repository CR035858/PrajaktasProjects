package com.gl.orders.ordersrestapi1.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gl.orders.ordersrestapi1.model.Order;



@Repository
public interface OrderJpaRepo extends JpaRepository<Order, Integer> {

}
