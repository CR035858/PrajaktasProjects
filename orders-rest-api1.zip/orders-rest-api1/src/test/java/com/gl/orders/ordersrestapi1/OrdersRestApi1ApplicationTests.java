package com.gl.orders.ordersrestapi1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersRestApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
